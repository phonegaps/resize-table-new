import React from "react";
import './Table.css'

// const inputTable = [
//     {
//         name: 'Order Info',
//         idLabel: 'ID',
//         salesDateLabel: 'Sales Date',
//         discountLabel: 'Discount',
//         modelPriceLabel: 'Model Price',
//         child: [
//             {
//                 id: '00762',
//                 salesDate: '12/27/2023',
//                 discount: '15.00%',
//                 modelPrice: '$49,995.00'
//             },
//             {
//                 id: '00713',
//                 salesDate: '12/27/2023',
//                 discount: '10.00%',
//                 modelPrice: '$72,905.00'
//             },
//             {
//                 id: '00398',
//                 salesDate: '12/27/2023',
//                 discount: '15.00%',
//                 modelPrice: '$4,995.00'
//             }
//         ]
//     },
//     {
//         name: 'Performance',
//         mpgCityLabel: 'MPG City',
//         mpgHighwayLabel: 'MPG Highway',
//         transmissionTypeLabel: 'Transmission Type',
//         transmissionSpeedsLabel: 'Transmission Speeds',
//         torqueLabel: 'Torque',
//         horsepowreLabel: 'Horsepowre',
//         cylindersLabel: 'Cylinders',
//         child: [
//             {
//                 mpgCity: '12',
//                 mpgHighway: '17',
//                 transmissionType: 'Automatic',
//                 transmissionSpeeds: '6',
//                 torque: '375@3500',
//                 horsepowre: '375@6500',
//                 cylinders: '8',
//             },
//             {
//                 mpgCity: '17',
//                 mpgHighway: '31',
//                 transmissionType: 'Manual',
//                 transmissionSpeeds: '8',
//                 torque: '258@1500',
//                 horsepowre: '211@4300',
//                 cylinders: '8',
//             },
//             {
//                 mpgCity: '15',
//                 mpgHighway: '30',
//                 transmissionType: 'Automatic',
//                 transmissionSpeeds: '7',
//                 torque: '443@1800',
//                 horsepowre: '402@5000',
//                 cylinders: '4',
//             }
//         ]
//     },
//     {
//         name: 'Moel',
//         trademarkLabel: 'Trademark',
//         categoryLabel: 'Category',
//         bodyStyleLabel: 'Body Style',
//         doorsLabel: 'Doors',
//         modelNameLabel: 'Name',
//         modificationLabel: 'Modification',
//         child: [
//             {
//                 trademark: 'Land Rover',
//                 category: 'Crossover & SUV',
//                 bodyStyle: 'Sport Utility',
//                 doors: '5',
//                 modelName: 'LR4',
//                 modification: '5.0L V8 6A',
//             },
//             {
//                 trademark: 'Mercedes-Benz',
//                 category: 'Car',
//                 bodyStyle: 'Sedan',
//                 doors: '4',
//                 modelName: 'Cls550',
//                 modification: '4.6L V8 7A',
//             },
//             {
//                 trademark: 'Audi',
//                 category: 'Car',
//                 bodyStyle: 'Wagon',
//                 doors: '4',
//                 modelName: 'Allroad',
//                 modification: '2.0L I4 8A',
//             }
//         ]
//     },
// ]

// function transformData(inputTable) {
//     const output = [];

//     inputTable.forEach(section => {
//         const transformedSection = {
//             name: section.name,
//             child: {}
//         };
//         const keys = Object.keys(section.child[0]);
//         keys.forEach(key => {
//             transformedSection.child[`${key}Label`] = [key, ...section.child.map(item => item[key])];
//         });

//         output.push(transformedSection);
//     });

//     return output;
// }

// const outPut = transformData(inputTable);
// console.log(outPut);




// const outPut = [
//     {
//         name: 'Order Info',
//         child: {
//             idLabel: ['ID', '00762', '00713', '00398'],
//             salesDateLabel: ['Sales Date', '12/27/2023', '12/27/2023', '12/27/2023'],
//             discountLabel: ['Discount', '15.00%', '10.00%', '15.00%'],
//             modelPriceLabel: ['Model Price', '$49,995.00', '$72,905.00', '$4,995.00']
//         }
//     },
//     {
//         name: 'Performance',
//         mpgCityLabel: ['MPG City', '12', '17', '15', '15',],
//         mpgHighwayLabel: ['MPG Highway', '17', '31', '30',],
//         transmissionTypeLabel: ['Transmission Type', 'Automatic', 'Manual', 'Automatic'],
//         transmissionSpeedsLabel: ['Transmission Speeds', '6', '8', '7',],
//         torqueLabel: ['Torque', '375@3500', '258@1500', '443@1800'],
//         horsepowreLabel: ['Horsepowre', '375@6500', '258@1500', '211@4300'],
//         cylindersLabel: ['Cylinders', '8', '8', '4'],
//     },
//     {
//         name: 'Moel',
//         trademarkLabel: ['Trademark', 'Land Rover', 'Mercedes-Benz', 'Audi'],
//         categoryLabel: ['Category', 'Crossover & SUV', 'Car', 'Car'],
//         bodyStyleLabel: ['Body Style', 'Sport Utility', 'Sedan', 'Wagon'],
//         doorsLabel: ['Doors', '4', '5', '4'],
//         modelNameLabel: ['Name', 'LR4', 'Cls550', 'Allroad'],
//         modificationLabel: ['Modification', '5.0L V8 6A', '4.6L V8 7A', '2.0L I4 8A'],
//     }
// ]




const OrderInfo = () => {

    return (
        <>
            <div className="table-wrap">
                <div className="table-responsive">
                    <table className="tableBody">
                        <tr><td colSpan={6} className="titleContent"><p className="title">Order Info</p></td></tr>
                        <tr>
                            <td>ID</td>
                            <td>00762</td>
                            <td>00713</td>
                            <td>00398</td>
                            <td>00673</td>
                            <td>00398</td>
                        </tr>
                        <tr>
                            <td>Sales Date</td>
                            <td>12/27/2023</td>
                            <td>12/27/2023</td>
                            <td>12/27/2023</td>
                            <td>12/27/2023</td>
                            <td>12/27/2023</td>
                        </tr>
                        <tr>
                            <td>Discount</td>
                            <td>15.00%</td>
                            <td>10.00%</td>
                            <td>0.00%</td>
                            <td>10.00%</td>
                            <td>15.00%</td>
                        </tr>
                        <tr>
                            <td>Model Price</td>
                            <td>$49,995.00</td>
                            <td>$72,905.00</td>
                            <td>$40,495.00</td>
                            <td>$56,305.00</td>
                            <td>$49,995.00</td>
                        </tr>
                        <tr><td colSpan={6} className="titleContent"><p className="title">Performance</p></td></tr>
                        <tr>
                            <td>MPG City</td>
                            <td>12</td>
                            <td>15</td>
                            <td>17</td>
                            <td>10</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>Transmission Type</td>
                            <td>17</td>
                            <td>16</td>
                            <td>19</td>
                            <td>14</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>Torque</td>
                            <td>258@1500</td>
                            <td>358@1500</td>
                            <td>658@900</td>
                            <td>258@1500</td>
                            <td>278@1800</td>
                        </tr>
                        <tr>
                            <td>Cylinders</td>
                            <td>4</td>
                            <td>6</td>
                            <td>4</td>
                            <td>8</td>
                            <td>4</td>
                        </tr>
                        <tr><td colSpan={6} className="titleContent"><p className="title">Model</p></td></tr>
                        <tr>
                            <td>Trademark</td>
                            <td>Land Rover</td>
                            <td>Audi</td>
                            <td>Maruti</td>
                            <td>Mercedes</td>
                            <td>Land Rover</td>
                        </tr>
                        <tr>
                            <td>Category</td>
                            <td>Crossover & SUV</td>
                            <td>Car</td>
                            <td>Car</td>
                            <td>Crossover & SUV</td>
                            <td>Car</td>
                        </tr>
                        <tr>
                            <td>Body Style</td>
                            <td>Sport Utility Vehicle</td>
                            <td>Sedan</td>
                            <td>Wagon</td>
                            <td>Convertible</td>
                            <td>Sedan</td>
                        </tr>
                        <tr>
                            <td>Doors</td>
                            <td>4</td>
                            <td>5</td>
                            <td>2</td>
                            <td>4</td>
                            <td>5</td>
                        </tr>
                        <tr>
                            <td>Name</td>
                            <td>LR4</td>
                            <td>Cls550</td>
                            <td>Allroad</td>
                            <td>Slk350</td>
                            <td>Range Rover Supercharged</td>
                        </tr>
                        <tr>
                            <td>Modification</td>
                            <td>5.0L V8 6A</td>
                            <td>4.6L V8 7A</td>
                            <td>2.0L I4 8A</td>
                            <td>3.5L V6 7A</td>
                            <td>5.0L V8 8A</td>
                        </tr>
                    </table>
                </div>
            </div>
        </>
    )
}

export default OrderInfo;