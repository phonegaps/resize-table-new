import React, { useState, useCallback, useEffect, useRef } from "react";
import "./ResizableTables.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faRefresh, faAngleDown, faAngleRight } from "@fortawesome/free-solid-svg-icons";

const createHeaders = (headers) => {
    return headers?.map((item) => ({
        text: item,
        ref: useRef()
    }));
};

const ResizableTables = ({ headers, minCellWidth, tableContent, title }) => {
    const [tableHeight, setTableHeight] = useState("auto");
    const [activeIndex, setActiveIndex] = useState(null);
    const [headerHeight, setHeaderHeight] = useState('auto');
    const [isExpanded, setIsExpanded] = useState({});
    const tableElement = useRef(null);
    const columns = createHeaders(headers);

    useEffect(() => {
        setTableHeight(tableElement?.current?.offsetHeight);
    }, []);

    const handleStart = (index, e) => {
        e.preventDefault();
        setActiveIndex(index);
    };

    const handleMove = useCallback((e) => {
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        const gridColumns = columns?.map((col, i) => {
            if (i === activeIndex) {
                const width = clientX - col.ref.current.offsetLeft;
                if (width >= minCellWidth) {
                    return `${width}px`;
                }
            }
            return `${col.ref.current.offsetWidth}px`;
        });

        if (activeIndex === 'head') {
            const height = `${clientY}px`;
            setHeaderHeight(height);
        }

        tableElement.current.style.gridTemplateColumns = `${gridColumns.join(" ")}`;
    }, [activeIndex, columns, minCellWidth]);

    const removeListeners = useCallback(() => {
        window.removeEventListener("mousemove", handleMove);
        window.removeEventListener("touchmove", handleMove);
        window.removeEventListener("mouseup", handleEnd);
        window.removeEventListener("touchend", handleEnd);

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [handleMove]);

    const handleEnd = useCallback(() => {
        setActiveIndex(null);
        removeListeners();
    }, [setActiveIndex, removeListeners]);

    useEffect(() => {
        if (activeIndex !== null) {
            window.addEventListener("mousemove", handleMove);
            window.addEventListener("touchmove", handleMove, { passive: false });
            window.addEventListener("mouseup", handleEnd);
            window.addEventListener("touchend", handleEnd);
        }

        return () => {
            removeListeners();
        };
    }, [activeIndex, handleMove, handleEnd, removeListeners]);

    const resetTableCells = () => {
        tableElement.current.style.gridTemplateColumns = `minmax(150px, 3fr) ${' minmax(150px, 1fr)'.repeat(columns?.length - 1)}`;
        setHeaderHeight('auto');
    };

    const showHide = (id) => {
        setIsExpanded({ ...isExpanded, [id]: !isExpanded[id] });

        if (isExpanded !== false) {
            setHeaderHeight('auto');
        }
    };

    return (
        <div className="resize_wrapper">
            <div className={`resize_header ${!isExpanded[title] && 'headerEx'}`} style={{ height: headerHeight }}>
                <div className="header_wrapper">
                    <h4 className="resize_title">{title}</h4>
                    <div className="icon_wrap">
                        {!isExpanded[title] && <FontAwesomeIcon className="resize_reset" icon={faRefresh} onClick={resetTableCells} />}
                        <FontAwesomeIcon onClick={() => showHide(title)} className="resize_arrow" icon={!isExpanded[title] ? faAngleDown : faAngleRight} />
                    </div>
                </div>
                {!isExpanded[title] && <div className="resize_header_handle" onMouseDown={(e) => handleStart('head', e)} onTouchStart={(e) => handleStart('head', e)}></div>}
            </div>
            {!isExpanded[title] &&
                <div className="resize_body">
                    <table className="resize_table" ref={tableElement} style={{ gridTemplateColumns: `minmax(150px, 3fr) ${' minmax(150px, 1fr)'.repeat(columns?.length - 1)}` }}>
                        <thead>
                            <tr>
                                {columns?.map(({ ref, text }, i) => (
                                    <th ref={ref} key={i}>
                                        <span>{text}</span>
                                        <div
                                            style={{ height: tableHeight }}
                                            onMouseDown={(e) => handleStart(i, e)}
                                            onTouchStart={(e) => handleStart(i, e)}
                                            className={`resize-handle `} ></div>
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        {tableContent}
                    </table>
                </div>
            }
        </div>
    );
};

export default ResizableTables;
