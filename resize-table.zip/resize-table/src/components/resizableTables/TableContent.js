import React, { useState } from "react";

const TableContent = ({ tableBody }) => {
    const [bodyContent, setBodyContent] = useState(tableBody)
    const inputChangeHandler = (ri, e, ci) => {
        const updateValue = e.target.value;
        const updateData = [...bodyContent];
        updateData[ri].items[ci].value = updateValue;
        setBodyContent(updateData);
    }

    return (
        // <tbody>
        //     {Object.keys(bodyContent).map((key, rowIndex) => (
        //         <tr key={rowIndex}>
        //             {bodyContent[key].map((value, valueIndex) => (
        //                 <td key={valueIndex}>{value}</td>
        //             ))}
        //         </tr>
        //     ))}
        // </tbody>
        <tbody>
            {
                bodyContent && bodyContent.map((rowItem, ri) => (
                    <tr key={ri}>
                        {rowItem.items && rowItem.items?.map((col, ci) => (
                            col.type === 'label' ?
                                <td key={ci}>{col.value}</td> :
                                <td key={ci}><input className='inputField' type={col.type} value={col.value} onChange={(e) => inputChangeHandler(ri, e, ci)} /> </td>
                        ))}
                    </tr>
                ))
            }
        </tbody>
    );
};

export default TableContent;



