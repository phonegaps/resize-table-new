import React from "react";

const TableView = () => {
    const inputData = [{
        name: 'Order Info',
        child: [
            {
                ID: "00762",
                SalesDate: "12/27/2023",
                Discount: "15.00%",
                ModelPrice: "$49,995.00"
            },
            {
                ID: "00762",
                SalesDate: "12/27/2023",
                Discount: "15.00%",
                ModelPrice: "$49,995.00"
            },
            {
                ID: "00762",
                SalesDate: "12/27/2023",
                Discount: "15.00%",
                ModelPrice: "$49,995.00"
            },
            {
                ID: "00762",
                SalesDate: "12/27/2023",
                Discount: "15.00%",
                ModelPrice: "$49,995.00"
            },
            {
                ID: "00762",
                SalesDate: "12/27/2023",
                Discount: "15.00%",
                ModelPrice: "$49,995.00"
            }
        ]
    },
    {
        name: 'Sales Details',
        child: [
            {
                IID1: "0076243",
                SalesDate1: "12/27/2024",
                Discount1: "16.00%",
                ModelPrice1: "$49,95.00"
            },
            {
                ID1: "0076452",
                SalesDate1: "12/29/2023",
                Discount1: "15.00%",
                ModelPrice1: "$49,995.00"
            },
            {
                ID1: "0076892",
                SalesDate1: "12/7/2023",
                Discount1: "155.00%",
                ModelPrice1: "$495,995.00"
            },
            {
                ID1: "0077862",
                SalesDate1: "12/2/2023",
                Discount1: "1589.00%",
                ModelPrice1: "$490,995.00"
            },
            {
                ID1: "00762",
                SalesDate1: "12/27/2023",
                Discount1: "15.00%",
                ModelPrice1: "$49,995.00"
            }
        ]
    },
    ]

    function generateOutputView(inputData) {
        let outputHTML = '<div>';

        inputData.forEach((section) => {
            outputHTML += `<h2>${section.name}</h2>`;
            outputHTML += '<table>';
            outputHTML += '<tbody className="tableBody">';

            // Extracting keys dynamically to create table headers
            const keys = Object.keys(section.child[0]);

            // Generating table rows
            keys.forEach((key) => {
                outputHTML += '<tr>';
                outputHTML += `<td>${key}</td>`;

                section.child.forEach((item) => {
                    outputHTML += `<td>${item[key] !== undefined ? item[key] : 'undefined'}</td>`;
                });

                outputHTML += '</tr>';
            });

            outputHTML += '</tbody>';
            outputHTML += '</table>';
        });

        outputHTML += '</div>';

        return outputHTML;
    }

    // Example usage:
    // const outputView = generateOutputView(inputData);
    // console.log(outputView);


    return (
        <>
            <h2>hdgsdgsd</h2>
            <div>{generateOutputView(inputData)}</div>
        </>
    )
}

export default TableView;