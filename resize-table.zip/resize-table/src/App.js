import React, { useState } from 'react';
import ResizableTables from './components/resizableTables/ResizableTables';
import TableContent from './components/resizableTables/TableContent';

// const inputTable = [
//     {
//         name: 'Order Info',
//         idLabel: 'ID',
//         salesDateLabel: 'Sales Date',
//         discountLabel: 'Discount',
//         modelPriceLabel: 'Model Price',
//         child: [
//             {
//                 id: '00762',
//                 salesDate: '12/27/2023',
//                 discount: '15.00%',
//                 modelPrice: '$49,995.00'
//             },
//             {
//                 id: '00713',
//                 salesDate: '12/27/2023',
//                 discount: '10.00%',
//                 modelPrice: '$72,905.00'
//             },
//             {
//                 id: '00398',
//                 salesDate: '12/27/2023',
//                 discount: '15.00%',
//                 modelPrice: '$4,995.00'
//             }
//         ]
//     },
//     {
//         name: 'Performance',
//         mpgCityLabel: 'MPG City',
//         mpgHighwayLabel: 'MPG Highway',
//         transmissionTypeLabel: 'Transmission Type',
//         transmissionSpeedsLabel: 'Transmission Speeds',
//         torqueLabel: 'Torque',
//         horsepowreLabel: 'Horsepowre',
//         cylindersLabel: 'Cylinders',
//         child: [
//             {
//                 mpgCity: '12',
//                 mpgHighway: '17',
//                 transmissionType: 'Automatic',
//                 transmissionSpeeds: '6',
//                 torque: '375@3500',
//                 horsepowre: '375@6500',
//                 cylinders: '8',
//             },
//             {
//                 mpgCity: '17',
//                 mpgHighway: '31',
//                 transmissionType: 'Manual',
//                 transmissionSpeeds: '8',
//                 torque: '258@1500',
//                 horsepowre: '211@4300',
//                 cylinders: '8',
//             },
//             {
//                 mpgCity: '15',
//                 mpgHighway: '30',
//                 transmissionType: 'Automatic',
//                 transmissionSpeeds: '7',
//                 torque: '443@1800',
//                 horsepowre: '402@5000',
//                 cylinders: '4',
//             }
//         ]
//     },
//     {
//         name: 'Moel',
//         trademarkLabel: 'Trademark',
//         categoryLabel: 'Category',
//         bodyStyleLabel: 'Body Style',
//         doorsLabel: 'Doors',
//         modelNameLabel: 'Name',
//         modificationLabel: 'Modification',
//         child: [
//             {
//                 trademark: 'Land Rover',
//                 category: 'Crossover & SUV',
//                 bodyStyle: 'Sport Utility',
//                 doors: '5',
//                 modelName: 'LR4',
//                 modification: '5.0L V8 6A',
//             },
//             {
//                 trademark: 'Mercedes-Benz',
//                 category: 'Car',
//                 bodyStyle: 'Sedan',
//                 doors: '4',
//                 modelName: 'Cls550',
//                 modification: '4.6L V8 7A',
//             },
//             {
//                 trademark: 'Audi',
//                 category: 'Car',
//                 bodyStyle: 'Wagon',
//                 doors: '4',
//                 modelName: 'Allroad',
//                 modification: '2.0L I4 8A',
//             }
//         ]
//     },
// ]

// function transformData(inputTable) {
//     const output = [];

//     inputTable.forEach(section => {
//         const transformedSection = {
//             name: section.name,
//             child: {}
//         };
//         const keys = Object.keys(section.child[0]);
//         keys.forEach(key => {
//             transformedSection.child[`${key}Label`] = [key, ...section.child.map(item => item[key])];
//         });

//         output.push(transformedSection);
//     });

//     return output;
// }

// const outPut = transformData(inputTable);
// console.log(outPut);

function App() {
  const tableHeader = ["", "", "", ""];

  const inputData = [
    {
      name: 'Order Info',
      data: [
        {
          id: 1,
          items: [
            { type: 'label', value: 'ID' },
            { type: 'label', value: '00713' },
            { type: 'label', value: '00598' },
            { type: 'label', value: '00398' }
          ]
        },
        {
          id: 2,
          items: [
            { type: 'label', value: 'Sales Date' },
            { type: 'date', value: '12/27/2023' },
            { type: 'date', value: '12/27/2023' },
            { type: 'date', value: '12/27/2023' }
          ]
        },
        {
          id: 3,
          items: [
            { type: 'label', value: 'Discount' },
            { type: 'text', value: '15.00%' },
            { type: 'text', value: '10.00%' },
            { type: 'text', value: '11.00%' }
          ]
        },
        {
          id: 4,
          items: [
            { type: 'label', value: 'Model Price' },
            { type: 'text', value: '$49,995.00' },
            { type: 'text', value: '$72,905.00' },
            { type: 'text', value: '$4,995.00' }
          ]
        },
      ]
    },
    {
      name: 'Performance',
      data: [
        {
          id: 1,
          items: [
            { type: 'label', value: 'MPG City' },
            { type: 'text', value: '12' },
            { type: 'text', value: '17' },
            { type: 'text', value: '15' }
          ]
        },
        {
          id: 2,
          items: [
            { type: 'label', value: 'MPG Highway' },
            { type: 'text', value: '17' },
            { type: 'text', value: '31' },
            { type: 'text', value: '30' }
          ]
        },
        {
          id: 3,
          items: [
            { type: 'label', value: 'Transmission Type' },
            { type: 'text', value: 'Automatic' },
            { type: 'text', value: 'Manual' },
            { type: 'text', value: 'Automatic' }
          ]
        },
        {
          id: 4,
          items: [
            { type: 'label', value: 'Transmission Speeds' },
            { type: 'text', value: '6' },
            { type: 'text', value: '8' },
            { type: 'text', value: '7' }
          ]
        },
        {
          id: 5,
          items: [
            { type: 'label', value: 'Torque' },
            { type: 'text', value: '375@3500' },
            { type: 'text', value: '258@1500' },
            { type: 'text', value: '443@1800' }
          ]
        },
        {
          id: 6,
          items: [
            { type: 'label', value: 'Horsepower' },
            { type: 'text', value: '375@6500' },
            { type: 'text', value: '211@4300' },
            { type: 'text', value: '402@5000' }
          ]
        },
        {
          id: 7,
          items: [
            { type: 'label', value: 'Cylinders' },
            { type: 'text', value: '8' },
            { type: 'text', value: '8' },
            { type: 'text', value: '4' }
          ]
        },
      ]
    },
    {
      name: 'Model',
      data: [
        {
          id: 1,
          items: [
            { type: 'label', value: 'Trademark' },
            { type: 'text', value: 'Land Rover' },
            { type: 'text', value: 'Mercedes-Benz' },
            { type: 'text', value: 'Audi' }
          ]
        },
        {
          id: 2,
          items: [
            { type: 'label', value: 'Category' },
            { type: 'text', value: 'Crossover & SUV' },
            { type: 'text', value: 'Car' },
            { type: 'text', value: 'Car' }
          ]
        },
        {
          id: 3,
          items: [
            { type: 'label', value: 'Body Style' },
            { type: 'text', value: 'Sport Utility' },
            { type: 'text', value: 'Sedan' },
            { type: 'text', value: 'Wagon' }
          ]
        },
        {
          id: 4,
          items: [
            { type: 'label', value: 'Doors' },
            { type: 'text', value: '5' },
            { type: 'text', value: '4' },
            { type: 'text', value: '4' }
          ]
        },
        {
          id: 5,
          items: [
            { type: 'label', value: 'Model Name' },
            { type: 'text', value: 'LR4' },
            { type: 'text', value: 'Cls550' },
            { type: 'text', value: 'Allroad' }
          ]
        },
        {
          id: 6,
          items: [
            { type: 'label', value: 'Modification' },
            { type: 'text', value: '5.0L V8 6A' },
            { type: 'text', value: '4.6L V8 7A' },
            { type: 'text', value: '2.0L I4 8A' }
          ]
        },
      ]
    }
  ]

  const [columnWidth, setColumnWidth] = useState('minmax(150px, 2fr) minmax(150px, 1fr) minmax(150px, 1fr) minmax(150px, 1fr)');
  const onResize = (resizeCol) => {
    setColumnWidth(resizeCol);
  }

  return (
    <div className="bg-white">

      <div className='resize-content'>
        {inputData.map((column, columnIndex) => (
          <ResizableTables
            key={columnIndex + 1}
            headers={tableHeader}
            minCellWidth={120}
            tableContent={<TableContent tableBody={column.data} />}
            title={column.name}
            onResize={onResize}
            columnWidth={columnWidth}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
